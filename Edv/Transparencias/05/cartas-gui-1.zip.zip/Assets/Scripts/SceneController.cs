﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class SceneController : MonoBehaviour
{
    [SerializeField] private MemoryCard originalCard;
    [SerializeField] private Sprite[] images;

    private MemoryCard _first, _second;
    private int _score, _pairsFound = 0;
    public float timeOutSeconds = 3.0f;
    float currentTime;

    private UIController ui;

    public bool canReveal
    {
        get { return _second == null; }
    }

    private bool _paused;
    public bool paused
    {
        get { return _paused; }
        set
        {
            _paused = value;
            Time.timeScale = value ? 0.0f : 1.0f;
            ui.ShowPauseMenu(value);
        }
    }
    public bool gameover
    {
        get
        {
            return _pairsFound ==
             gridCols * gridRows / 2;
        }
    }
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            paused = !paused;
        }
        if (paused) return;


        currentTime -= Time.deltaTime;
        if (currentTime < 0)
        {
            if (_score > 0)
            {
                _score--; ui.SetScore(_score);
            }
            ResetTimeOut();
        }
        ui.SetTimeOutValue(currentTime / timeOutSeconds);
    }
    void ResetTimeOut()
    {
        currentTime = timeOutSeconds;
    }

    public void CardRevealed(MemoryCard c)
    {
        ResetTimeOut();

        if (_first == null)
        {
            _first = c;
        }
        else
        {
            _second = c;
            //Debug.Log(_first.id == _second.id ? "YES" : "NO");
            StartCoroutine(CheckMatch());
        }
    }

    private IEnumerator CheckMatch()
    {
        if (_first.id == _second.id)
        {
            _score++;
            //Debug.Log("Score: " + _score);
            ui.SetScore(_score);
            _pairsFound++;
            if (gameover)
            {
                ui.EnableTimeOutBar(false);
                paused = true;
            }
        }
        else
        {
            yield return new WaitForSeconds(.5f);
            _first.Unreveal();
            _second.Unreveal();
        }
        _first = _second = null;

    }

    public int gridRows = 2;
    public int gridCols = 4;
    public float header = 2f;
    public float margin = 1f;

    void Start()
    {

        ui = GetComponent<UIController>();
        paused = false;

        _score = 0;
        int[] ids = new int[gridRows * gridCols];
        for (int i = 0; i < ids.Length; i++)
        {
            ids[i] = i / 2;
        }
        ids = ShuffleArray(ids);

        float totalheight = Camera.main.orthographicSize * 2;
        float totalwidth = totalheight * Camera.main.aspect;
        float cardWidth = (totalwidth - 2 * margin) / gridCols;
        float cardHeight = (totalheight - header - margin) / gridRows;
        for (int j = 0; j < gridRows; j++)
        {
            for (int i = 0; i < gridCols; i++)
            {
                MemoryCard card = Instantiate(originalCard) as MemoryCard;
                //int id = Random.Range(0, images.Length);
                int index = j * gridCols + i;
                int id = ids[index];
                card.SetCard(id, images[id]);

                float posX = (i + 0.5f) * cardWidth - totalwidth / 2 + margin;
                float posY = (j + 0.5f) * cardHeight - totalheight / 2 + margin;
                card.transform.position = new Vector3(posX, posY, originalCard.transform.position.z);
            }
        }
    }

    private int[] ShuffleArray(int[] numbers)
    {
        int[] newArray = numbers.Clone() as int[];
        for (int i = 0; i < newArray.Length - 1; i++)
        {
            int r = Random.Range(i, newArray.Length);
            int tmp = newArray[i];
            newArray[i] = newArray[r];
            newArray[r] = tmp;
        }
        return newArray;
    }

    public void Restart()
    {
        SceneManager.LoadScene("SampleScene");
    }

    public void Quit()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
  Application.Quit();
#endif

    }

}

