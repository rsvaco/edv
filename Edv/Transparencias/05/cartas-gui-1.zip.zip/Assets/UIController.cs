﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class UIController : MonoBehaviour
{

    [SerializeField] private TextMeshProUGUI scoreLabel;
    [SerializeField] private RawImage timeoutBar;
    [SerializeField] private GameObject pauseMenu;
    [SerializeField] private SceneController sceneController;

    public void ShowPauseMenu(bool show)
    {
        pauseMenu.SetActive(show);
    }
    public void SetTimeOutValue(float timeout)
    {
        timeoutBar.transform.localScale = new Vector3(timeout, 1.0f);
    }

    public void EnableTimeOutBar(bool enable)
    {
        timeoutBar.gameObject.SetActive(enable);
    }

    public void SetScore(int score)
    {
        scoreLabel.text = score.ToString();
    }

    public void OnOpenSettings()
    {
        sceneController.paused = true;
    }
}
