﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Parallax : MonoBehaviour
{
    private float startPosition;
    private Transform cam;
    public float parallaxFraction;

    void Start()
    {
        startPosition = transform.position.x;
        cam = Camera.main.transform;
    }

    void LateUpdate()
    {
        float offset = (cam.position.x * parallaxFraction);
        transform.position = new Vector3(startPosition + offset,
          transform.position.y,
          transform.position.z);
    }
}
