﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Eject : MonoBehaviour
{
    public float jumpForce = 30f;
    private Animator _anim;
    void Awake()
    {
        _anim = GetComponent<Animator>();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            PlatformerPlayer p = other.GetComponent<PlatformerPlayer>();
            p.Jump(jumpForce, true);
            _anim.SetTrigger("release");
        }
    }

}
